﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace csvtoxml
{
    public partial class Form1 : Form
    {
        string inputfile = "file.csv";
        string outputfile = "file.xml";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            if(!File.Exists(outputfile))
            {
                File.Create(outputfile).Dispose();
            }
            File.AppendAllText(outputfile, "<?xml version=\"1.0\"?>\n<items>\n");
            string[] header = new string[100];
            int i = 0;
            using(StreamReader reader=new StreamReader(inputfile))
            {
                string line;
                while((line = reader.ReadLine())!=null)
                {
                    if(i==0)
                    {
                        string[] headers = line.Split(',');
                        int j = 0;
                        foreach(string head in headers)
                        {
                            header[j] = head;
                            j++;
                        }
                        i++;
                    }
                    else
                    {
                        int z = 0;
                        File.AppendAllText(outputfile, "<item>\n");
                        string[] values = line.Split(',');
                        foreach(string value in values)
                        {
                            string add = "<" + header[z] + ">" + value + "</" + header[z] + ">";
                            File.AppendAllText(outputfile, add);
                            z++;
                        }
                        File.AppendAllText(outputfile, "</item>\n");
                    }

                }
            }
            File.AppendAllText(outputfile, "</items>");
        }
    }
}
